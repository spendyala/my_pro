# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('vfd_app', '0006_auto_20150808_2207'),
    ]

    operations = [
        migrations.AddField(
            model_name='client_vfd_motor_data_per_month',
            name='vfd_set_point',
            field=models.FloatField(default=80, verbose_name=b'VFD Set point'),
        ),
    ]
